import Classes.WelcomeNote;

public class HMSMain {
    public static void main(String[] args) {
        new WelcomeNote();
    }
    
}
