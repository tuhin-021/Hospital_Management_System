package Oparetions;

public interface AddUserOp {
    public abstract void adduser(String username,String password,String name,String email);
    
}
