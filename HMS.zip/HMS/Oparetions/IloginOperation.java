package Oparetions;



public interface IloginOperation {
    void matchinAdmin(String textField1, String textField2);

    void matchinUser(String textField1, String textField2);
}