package Classes;
import javax.swing.*;
import java.awt.Font;
import java.awt.event.*;
import java.awt.Color;
import java.awt.Cursor;
import static javax.swing.JOptionPane.showMessageDialog;

public class Login extends LoginCond {
    JFrame f1;
    JPanel p1;

    JLabel l1, l2, l3, l4, l6, l7, l9, l10;
    JTextField tf1;
    JPasswordField pf1;
    JButton b2, b3;
    ImageIcon i1;
    JRadioButton r1, r2;
    ButtonGroup bg1;
    int pc = 0;

    public Login(String textField1, String textField2) {
        super(textField1, textField2);

        f1 = new JFrame();

        p1 = new JPanel();
        p1.setBounds(135,20,500,540);
        p1.setBackground(new Color(255, 255, 255));

        

        l1 = new JLabel("Log In");
        l1.setBounds(330, 30, 200, 60);
        l1.setForeground(Color.black);
        l1.setFont(new Font("Segoe UI", Font.BOLD, 35));
        f1.add(l1);
		
		

        l2 = new JLabel("Hello! Let's get started");
        l2.setBounds(275, 80, 300, 40);
        l2.setForeground(Color.black);
        l2.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        f1.add(l2);

//530 265
        bg1 = new ButtonGroup();
        r1 = new JRadioButton("Admin Login");
        r1.setBounds(250, 140, 150, 20);
        r1.setFont(new Font("Segoe UI", Font.BOLD, 15));
        r1.setCursor(new Cursor(Cursor.HAND_CURSOR));
        r1.setForeground(Color.black);
        r1.setBorderPainted(false);
        r1.setContentAreaFilled(false);
        r1.setFocusPainted(false);

        r2 = new JRadioButton("User Login");
        r2.setBounds(400, 140, 150, 20);
        r2.setFont(new Font("Segoe UI", Font.BOLD, 15));
        r2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        r2.setForeground(Color.black);
        r2.setBorderPainted(false);
        r2.setContentAreaFilled(false);
        r2.setFocusPainted(false);
        bg1.add(r1);
        bg1.add(r2);
        f1.add(r1);
        f1.add(r2);
//46
        l3 = new JLabel("User Name");
        l3.setBounds(180, 186, 300, 40);
        l3.setForeground(Color.black);
        l3.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        f1.add(l3);
        tf1 = new JTextField(); //39
        tf1.setBounds(180, 225, 380, 30);
        tf1.setFont(new Font("Segoe UI", Font.PLAIN, 22));
        tf1.setForeground(Color.black);
        tf1.setCursor(new Cursor(Cursor.TEXT_CURSOR));

        l4 = new JLabel("Password"); //41
        l4.setBounds(180, 266, 150, 40);
        l4.setForeground(Color.black);
        l4.setFont(new Font("Segoe UI", Font.PLAIN, 20));
        pf1 = new JPasswordField(); //39
        pf1.setBounds(180, 305, 380, 30);
        pf1.setFont(new Font("Segoe UI", Font.PLAIN, 22));
        pf1.setForeground(Color.black);
        pf1.setCursor(new Cursor(Cursor.TEXT_CURSOR));

     


        b2 = new JButton("Login");
        b2.setBounds(180, 350, 400, 40);
        b2.setFont(new Font("Segoe UI", Font.BOLD, 25));
        b2.setForeground(new Color(255, 255, 255));
        b2.setBackground(new Color(95, 112, 234));
        b2.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b2.setFocusPainted(false);

        l9 = new JLabel("Don't have an account?");
        l9.setBounds(160, 400, 240, 40);
        l9.setForeground(Color.black);
        l9.setFont(new Font("Segoe UI", Font.PLAIN, 22));

        b3 = new JButton("Sign Up");
        b3.setBounds(420, 400, 90, 40);
        b3.setForeground(Color.white);
        b3.setFont(new Font("Segoe UI", Font.BOLD, 20));
        b3.setForeground(new Color(0, 0, 0));
        b3.setCursor(new Cursor(Cursor.HAND_CURSOR));
        b3.setFocusPainted(false);
        b3.setBorder(BorderFactory.createEmptyBorder(4, 4, 4, 4));
        b3.setContentAreaFilled(false);

        f1.add(l4);
        
        f1.add(l9);
        f1.add(tf1);
        f1.add(pf1);
        f1.add(b2);
        f1.add(b3);
     



        f1.add(p1);

        f1.setSize(800, 640);
        f1.setLocationRelativeTo(null);
        f1.setLayout(null);
        f1.setVisible(true);
        f1.setResizable(false);
        f1.getContentPane().setBackground(new Color (135,206,235));  //skyblue colour BackgROUND
        f1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);



        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {

                if (e.getSource() == b3) {
                    new AddUser("username", "password", "name", "email").setVisible(true);
                    f1.setVisible(false);

                }
            }
        });

        r1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == r1) {
                    pc = 1;
                }
            }
        });

        r2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (e.getSource() == r2) {
                    pc = 2;
                }
            }
        });

        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent ae) {

                String textField1 = tf1.getText().toLowerCase(); // User Name
                char[] passwordChars = pf1.getPassword(); // Preferred

            // Convert char array to String if needed
            String textField2 = new String(passwordChars);



                if (pc == 1) {
                    if ((!textField1.isEmpty() && !textField2.isEmpty())) {

                        matchinAdmin(textField1, textField2);

                        if (s == 1) {
                            f1.setVisible(false);
                        }

                    } else {
                        showMessageDialog(null, " Fill the blank fields ", "Message", 2);
                    }
                }

                else if (pc == 2) {
                    if (!textField1.isEmpty() && !textField2.isEmpty()) {

                        matchinUser(textField1, textField2);

                        if (s == 2) {
                            f1.setVisible(false);
                        }

                    } else {
                        showMessageDialog(null, " Fill all fields ", "Message", 2);
                    }

                } else if (pc != 2 || pc != 1) {
                    showMessageDialog(null, " Choose User type ", "Message", 2);
                }

            }
        });
    }

}
