package Classes;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;


public class surgeons extends JFrame implements MouseListener,ActionListener
{
	JButton doctorname16,doctorname17,fee16,fee17,appointment16,appointment17,back18;
	JPanel panel;
	Color mycolor;

	public surgeons()
	{
		super("Surgeons");
		this.setSize(800,600);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		mycolor=new Color(176,196,222);
		
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor);
		
		doctorname16 = new JButton("DR.MALIHA KHANAM");
		doctorname16.setBounds(100, 200, 200, 30);
		doctorname16.setBackground(Color.decode("#E0FFFF"));
		doctorname16.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname16.setFocusable(false);
		doctorname16.setOpaque(true);
		doctorname16.setForeground(Color.BLACK);
		doctorname16.addMouseListener(this);
		doctorname16.addActionListener(this);
		panel.add(doctorname16);
		
		doctorname17 = new JButton("DR.SAIFUL ISLAM");
		doctorname17.setBounds(450,200, 200, 30);
		doctorname17.setBackground(Color.decode("#E0FFFF"));
		doctorname17.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname17.setFocusable(false);
		doctorname17.setOpaque(true);
		doctorname17.setForeground(Color.BLACK);
		doctorname17.addMouseListener(this);
		doctorname17.addActionListener(this);
		panel.add(doctorname17);
		
		fee16 = new JButton("TIME:9-12 AM");
		fee16.setBounds(100, 230, 200, 30);
		fee16.setBackground(Color.decode("#E0FFFF"));
		fee16.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee16.setFocusable(false);
		fee16.setOpaque(true);
		fee16.setForeground(Color.BLACK);
		fee16.addMouseListener(this);
		fee16.addActionListener(this);
		panel.add(fee16);
		
		fee17 = new JButton("TIME:6-9 PM");
		fee17.setBounds(450, 230, 200, 30);
		fee17.setBackground(Color.decode("#E0FFFF"));
		fee17.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee17.setFocusable(false);
		fee17.setOpaque(true);
		fee17.setForeground(Color.BLACK);
		fee17.addMouseListener(this);
		fee17.addActionListener(this);
		panel.add(fee17);
		
		appointment16 = new JButton("GET APPOINTMENT");
		appointment16.setBounds(100,300, 200, 30);
		appointment16.setBackground(Color.decode("#E0FFFF"));
		appointment16.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment16.setFocusable(false);
		appointment16.setOpaque(true);
		appointment16.setForeground(Color.BLACK);
		appointment16.addMouseListener(this);
		appointment16.addActionListener(this);
		panel.add(appointment16);
		
		appointment17 = new JButton("GET APPOINTMENT");
		appointment17.setBounds(450,300,200, 30);
		appointment17.setBackground(Color.decode("#E0FFFF"));
		appointment17.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment17.setFocusable(false);
		appointment17.setOpaque(true);
		appointment17.setForeground(Color.BLACK);
		appointment17.addMouseListener(this);
		appointment17.addActionListener(this);
		panel.add(appointment17);
		
		back18 = new JButton("<<");
		back18.setBounds(20,10,80,40);
		back18.setBackground(Color.decode("#B0C4DE"));
		back18.setFont(new Font("Copper BLACK",Font.BOLD,25));
		back18.setFocusable(false);
		back18.setOpaque(true);
		back18.setForeground(Color.BLACK);
		back18.addMouseListener(this);
		back18.addActionListener(this);
		panel.add(back18);
		
		this.setVisible(true);
		this.add(panel);
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){
		if(me.getSource()==back18)
		{
			back18.setBackground(Color.RED);
		}
	}
	public void mouseExited(MouseEvent me){
		if(me.getSource()==back18)
		{
			back18.setBackground(Color.decode("#B0C4DE"));
		}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String command = ae.getActionCommand();
		
		{
			if (appointment16.getText().equals(command))
			{
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (appointment17.getText().equals(command))
			    {
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (back18.getText().equals(command))
				{
					docdep dd=new docdep();
				    dd.setVisible(true);
				    this.setVisible(false);
				}
		
			
		}
	}

}