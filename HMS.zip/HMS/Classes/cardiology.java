package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class cardiology extends JFrame implements MouseListener,ActionListener
{
	private JButton doctorname18,doctorname19,fee18,fee19,appointment18,appointment19,back19;
	JPanel panel;
	Color mycolor;

	public cardiology()
	{
		super("Cardiologists");
		this.setSize(800,600);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		mycolor=new Color(176,196,222);
		
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor);
		
		doctorname18 = new JButton("DR.MALIHA KHANAM");
		doctorname18.setBounds(100, 200, 200, 30);
		doctorname18.setBackground(Color.decode("#E0FFFF"));
		doctorname18.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname18.setFocusable(false);
		doctorname18.setOpaque(true);
		doctorname18.setForeground(Color.BLACK);
		doctorname18.addMouseListener(this);
		doctorname18.addActionListener(this);
		panel.add(doctorname18);
		
		doctorname19 = new JButton("DR.SAIFUL ISLAM");
		doctorname19.setBounds(450,200, 200, 30);
		doctorname19.setBackground(Color.decode("#E0FFFF"));
		doctorname19.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname19.setFocusable(false);
		doctorname19.setOpaque(true);
		doctorname19.setForeground(Color.BLACK);
		doctorname19.addMouseListener(this);
		doctorname19.addActionListener(this);
		panel.add(doctorname19);
		
		fee18 = new JButton("TIME:6-9 PM");
		fee18.setBounds(100, 230, 200, 30);
		fee18.setBackground(Color.decode("#E0FFFF"));
		fee18.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee18.setFocusable(false);
		fee18.setOpaque(true);
		fee18.setForeground(Color.BLACK);
		fee18.addMouseListener(this);
		fee18.addActionListener(this);
		panel.add(fee18);
		
		fee19 = new JButton("TIME:9-12 AM");
		fee19.setBounds(450, 230, 200, 30);
		fee19.setBackground(Color.decode("#E0FFFF"));
		fee19.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee19.setFocusable(false);
		fee19.setOpaque(true);
		fee19.setForeground(Color.BLACK);
		fee19.addMouseListener(this);
		fee19.addActionListener(this);
		panel.add(fee19);
		
		appointment18 = new JButton("GET APPOINTMRNT");
		appointment18.setBounds(100,300, 200, 30);
		appointment18.setBackground(Color.decode("#E0FFFF"));
		appointment18.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment18.setFocusable(false);
		appointment18.setOpaque(true);
		appointment18.setForeground(Color.BLACK);
		appointment18.addMouseListener(this);
		appointment18.addActionListener(this);
		panel.add(appointment18);
		
		appointment19 = new JButton("GET APPOINTMRNT");
		appointment19.setBounds(450,300,200, 30);
		appointment19.setBackground(Color.decode("#E0FFFF"));
		appointment19.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment19.setFocusable(false);
		appointment19.setOpaque(true);
		appointment19.setForeground(Color.BLACK);
		appointment19.addMouseListener(this);
		appointment19.addActionListener(this);
		panel.add(appointment19);
		
		back19 = new JButton("<<");
		back19.setBounds(20,10,80,40);
		back19.setBackground(Color.decode("#B0C4DE"));
		back19.setFont(new Font("Copper BLACK",Font.BOLD,25));
		back19.setFocusable(false);
		back19.setOpaque(true);
		back19.setForeground(Color.BLACK);
		back19.addMouseListener(this);
		back19.addActionListener(this);
		panel.add(back19);
		
		this.setVisible(true);
		this.add(panel);
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){
		if(me.getSource()==back19)
		{
			back19.setBackground(Color.RED);
		}
	}
	public void mouseExited(MouseEvent me){
		if(me.getSource()==back19)
		{
			back19.setBackground(Color.decode("#B0C4DE"));
		}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String command = ae.getActionCommand();
		
		{
			if (appointment18.getText().equals(command))
			{
				JOptionPane.showMessageDialog(null,"APPOINTMRNT CONFIRMED");
				}
				else if (appointment19.getText().equals(command))
			    {
				JOptionPane.showMessageDialog(null,"APPOINTMRNT CONFIRMED");
				}
				else if (back19.getText().equals(command))
				{
					docdep dd=new docdep();
				    dd.setVisible(true);
				    this.setVisible(false);
				}
		
			
		}
	}

}