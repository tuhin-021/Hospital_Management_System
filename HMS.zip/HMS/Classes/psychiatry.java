package Classes;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;


public class psychiatry extends JFrame implements MouseListener,ActionListener
{
	JButton doctorname8,doctorname9,fee8,fee9,appointment8,appointment9,back14;
	JPanel panel;
	Color mycolor;

	public psychiatry()
	{
		super("Psychiatrists");
		this.setSize(800,600);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		mycolor=new Color(176,196,222);
		
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor);
		
		doctorname8 = new JButton("DR.MALIHA KHANAM");
		doctorname8.setBounds(100, 200, 200, 30);
		doctorname8.setBackground(Color.decode("#E0FFFF"));
		doctorname8.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname8.setFocusable(false);
		doctorname8.setOpaque(true);
		doctorname8.setForeground(Color.BLACK);
		doctorname8.addMouseListener(this);
		doctorname8.addActionListener(this);
		panel.add(doctorname8);
		
		doctorname9 = new JButton("DR.SAIFUL ISLAM");
		doctorname9.setBounds(450,200, 200, 30);
		doctorname9.setBackground(Color.decode("#E0FFFF"));
		doctorname9.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname9.setFocusable(false);
		doctorname9.setOpaque(true);
		doctorname9.setForeground(Color.BLACK);
		doctorname9.addMouseListener(this);
		doctorname9.addActionListener(this);
		panel.add(doctorname9);
		
		fee8 = new JButton("TIME:6-9 PM");
		fee8.setBounds(100, 230, 200, 30);
		fee8.setBackground(Color.decode("#E0FFFF"));
		fee8.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee8.setFocusable(false);
		fee8.setOpaque(true);
		fee8.setForeground(Color.BLACK);
		fee8.addMouseListener(this);
		fee8.addActionListener(this);
		panel.add(fee8);
		
		fee9 = new JButton("TIME:9-12 AM");
		fee9.setBounds(450, 230, 200, 30);
		fee9.setBackground(Color.decode("#E0FFFF"));
		fee9.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee9.setFocusable(false);
		fee9.setOpaque(true);
		fee9.setForeground(Color.BLACK);
		fee9.addMouseListener(this);
		fee9.addActionListener(this);
		panel.add(fee9);
		
		appointment8 = new JButton("GET APPOINTMENT");
		appointment8.setBounds(100,300, 200, 30);
		appointment8.setBackground(Color.decode("#E0FFFF"));
		appointment8.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment8.setFocusable(false);
		appointment8.setOpaque(true);
		appointment8.setForeground(Color.BLACK);
		appointment8.addMouseListener(this);
		appointment8.addActionListener(this);
		panel.add(appointment8);
		
		appointment9 = new JButton("GET APPOINTMENT");
		appointment9.setBounds(450,300,200, 30);
		appointment9.setBackground(Color.decode("#E0FFFF"));
		appointment9.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment9.setFocusable(false);
		appointment9.setOpaque(true);
		appointment9.setForeground(Color.BLACK);
		appointment9.addMouseListener(this);
		appointment9.addActionListener(this);
		panel.add(appointment9);
		
		back14 = new JButton("<<");
		back14.setBounds(20,10,80,40);
		back14.setBackground(Color.decode("#B0C4DE"));
		back14.setFont(new Font("Copper BLACK",Font.BOLD,25));
		back14.setFocusable(false);
		back14.setOpaque(true);
		back14.setForeground(Color.BLACK);
		back14.addMouseListener(this);
		back14.addActionListener(this);
		panel.add(back14);
		
		this.setVisible(true);
		this.add(panel);
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){
		if(me.getSource()==back14)
		{
			back14.setBackground(Color.RED);
		}
	}
	public void mouseExited(MouseEvent me){
		if(me.getSource()==back14)
		{
			back14.setBackground(Color.decode("#B0C4DE"));
		}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String command = ae.getActionCommand();
		
		{
			if (appointment8.getText().equals(command))
			{
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (appointment9.getText().equals(command))
			    {
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (back14.getText().equals(command))
				{
					docdep dd=new docdep();
				    dd.setVisible(true);
				    this.setVisible(false);
				}
		
			
		}
	}

}