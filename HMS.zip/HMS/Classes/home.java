package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class home extends JFrame implements MouseListener,ActionListener
{
	JButton docdep,paybill,balance,settings;
	JPanel panel,panel1;
	Color mycolor;
	JLabel pic;
	int k=0;

	public home()
	{
		super("HOME");
		this.setSize(800,600);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		mycolor=new Color(173,216,230);
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor);

		ImageIcon icon = new ImageIcon("Images/second.jpg");
        pic=new JLabel(icon);
        pic.setBounds(0,0,550,600);
        pic.setBackground(Color.decode("#42f5ad"));
        panel.add(pic);
		
		
		
	    docdep = new JButton("FIND DOCTORS");
	    docdep.setBounds(560, 200,200,30);
		docdep.setBackground(Color.decode("#ADD8E6"));
		docdep.setFont(new Font("Copper BLACK",Font.BOLD,15));
		docdep.setFocusable(false);
		docdep.setOpaque(true);
		docdep.setForeground(Color.BLACK);
		docdep.addMouseListener(this);
		docdep.addActionListener(this);
		panel.add(docdep);
		
		paybill = new JButton("PAY BILL");
		paybill.setBounds(560, 250, 200, 30);
        paybill.setBackground(Color.decode("#ADD8E6"));
		paybill.setFont(new Font("Copper BLACK",Font.BOLD,15));
		paybill.setFocusable(false);
		paybill.setOpaque(true);
	    paybill.setForeground(Color.BLACK);
		paybill.addMouseListener(this);
        paybill.addActionListener(this);
		panel.add(paybill);
		
		
		balance = new JButton("BALANCE");
		balance.setBounds(560, 300, 200, 30);
        balance.setBackground(Color.decode("#ADD8E6"));
		balance.setFont(new Font("Copper BLACK",Font.BOLD,15));
		balance.setFocusable(false);
		balance.setOpaque(true);
	    balance.setForeground(Color.BLACK);
		balance.addMouseListener(this);
        balance.addActionListener(this);
		panel.add(balance);
		
		settings = new JButton("LOGOUT");
		settings.setBounds(560, 350, 200, 30);
        settings.setBackground(Color.decode("#ADD8E6"));
		settings.setFont(new Font("Copper BLACK",Font.BOLD,15));
		settings.setFocusable(false);
		settings.setOpaque(true);
	    settings.setForeground(Color.BLACK);
		settings.addMouseListener(this);
        settings.addActionListener(this);
		panel.add(settings);
		
		this.setVisible(true);
		this.add(panel);
	}
		
		
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){}
	public void mouseExited(MouseEvent me){}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String command=ae.getActionCommand();
		
		if(docdep.getText().equals(command))
		{
			new docdep();
			this.setVisible(false);
		}
		
		else if(paybill.getText().equals(command))
		{
			JOptionPane.showMessageDialog(null,"Payment successfull",command, 2);
			
			k=1;
		}
		
		else if(balance.getText().equals(command))
		{
			JOptionPane.showMessageDialog(null,"Balance : 0 ",command, 2);
			
			k=1;
		}
		else if(settings.getText().equals(command))
		{
			new Login("textField1","textField2");
			this.setVisible(false);
		}

		if(k==1){
			new home();
		}
		
	
	}
	
}
	