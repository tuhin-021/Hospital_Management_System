package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class docdep extends JFrame implements MouseListener,ActionListener{
	JButton orthopedics,dermatology,gynecology,pathology,cardiology,psychiatry,dental,eyesp,physicians,surgeons,back9;
	JPanel panel;

	JLabel pic;

	public docdep()
	{
		super("Department of Doctors");
		this.setSize(800,600);
		 this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
	
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(Color.decode("#BFFFFC"));



		ImageIcon icon = new ImageIcon("Images/third.jpg");
        pic=new JLabel(icon);
        pic.setBounds(300,30,450,500);
        pic.setBackground(Color.decode("#42f5ad"));
        panel.add(pic);
		
	    orthopedics = new JButton("ORTHOPEDICS");
	    orthopedics.setBounds(30, 80,200, 30);
		orthopedics.setBackground(Color.decode("#6495ED"));
		orthopedics.setFont(new Font("Copper BLACK",Font.BOLD,15));
		orthopedics.setFocusable(false);
		orthopedics.setOpaque(true);
		orthopedics.setForeground(Color.WHITE);
		orthopedics.addMouseListener(this);
		orthopedics.addActionListener(this);
		panel.add(orthopedics);
		
		dermatology = new JButton("DERMATOLOGISTS");
		dermatology.setBounds(30, 115, 200, 30);
        dermatology.setBackground(Color.decode("#6495ED"));
		dermatology.setFont(new Font("Copper BLACK",Font.BOLD,15));
		dermatology.setFocusable(false);
		dermatology.setOpaque(true);
	    dermatology.setForeground(Color.WHITE);
		dermatology.addMouseListener(this);
        dermatology.addActionListener(this);
		panel.add(dermatology);
		
		
		gynecology = new JButton("GYNECOLOGISTS");
		gynecology.setBounds(30, 150, 200, 30);
        gynecology.setBackground(Color.decode("#6495ED"));
		gynecology.setFont(new Font("Copper BLACK",Font.BOLD,15));
		gynecology.setFocusable(false);
	    gynecology.setOpaque(true);
	    gynecology.setForeground(Color.WHITE);
		gynecology.addMouseListener(this);
        gynecology.addActionListener(this);
		panel.add(gynecology);
		
		pathology = new JButton("PATHOLOGISTS");
		pathology.setBounds(30, 185, 200, 30);
        pathology.setBackground(Color.decode("#6495ED"));
		pathology.setFont(new Font("Copper BLACK",Font.BOLD,15));
		pathology.setFocusable(false);
		pathology.setOpaque(true);
	    pathology.setForeground(Color.WHITE);
		pathology.addMouseListener(this);
        pathology.addActionListener(this);
		panel.add(pathology);
		
		cardiology = new JButton("CARDIOLOGISTS");
		cardiology.setBounds(30, 220, 200, 30);
        cardiology.setBackground(Color.decode("#6495ED"));
		cardiology.setFont(new Font("Copper BLACK",Font.BOLD,15));
		cardiology.setFocusable(false);
		cardiology.setOpaque(true);
	    cardiology.setForeground(Color.WHITE);
		cardiology.addMouseListener(this);
        cardiology.addActionListener(this);
		panel.add(cardiology);
		
		psychiatry = new JButton("PSYCHIATRISTS");
		psychiatry.setBounds(30,255,200, 30);
        psychiatry.setBackground(Color.decode("#6495ED"));
		psychiatry.setFont(new Font("Copper BLACK",Font.BOLD,15));
		psychiatry.setFocusable(false);
		psychiatry.setOpaque(true);
	    psychiatry.setForeground(Color.WHITE);
		psychiatry.addMouseListener(this);
        psychiatry.addActionListener(this);
		panel.add(psychiatry);
		
		dental = new JButton("DENTISTS");
		dental.setBounds(30, 290, 200, 30);
        dental.setBackground(Color.decode("#6495ED"));
		dental.setFont(new Font("Copper BLACK",Font.BOLD,15));
		dental.setFocusable(false);
		dental.setOpaque(true);
	    dental.setForeground(Color.WHITE);
		dental.addMouseListener(this);
        dental.addActionListener(this);
		panel.add(dental);
		
		eyesp = new JButton("EYE SPECIALISTS");
		eyesp.setBounds(30, 325, 200, 30);
        eyesp.setBackground(Color.decode("#6495ED"));
		eyesp.setFont(new Font("Copper BLACK",Font.BOLD,15));
		eyesp.setFocusable(false);
		eyesp.setOpaque(true);
	    eyesp.setForeground(Color.WHITE);
		eyesp.addMouseListener(this);
        eyesp.addActionListener(this);
		panel.add(eyesp);
		
		physicians = new JButton("PHYSICIANS");
		physicians.setBounds(30, 360, 200, 30);
        physicians.setBackground(Color.decode("#6495ED"));
		physicians.setFont(new Font("Copper BLACK",Font.BOLD,15));
		physicians.setFocusable(false);
		physicians.setOpaque(true);
        physicians.setForeground(Color.WHITE);
		physicians.addMouseListener(this);
        physicians.addActionListener(this);
		panel.add(physicians);
		
		surgeons = new JButton("SURGEONS");
		surgeons.setBounds(30, 395, 200, 30);
        surgeons.setBackground(Color.decode("#6495ED"));
		surgeons.setFont(new Font("Copper BLACK",Font.BOLD,15));
		surgeons.setFocusable(false);
		surgeons.setOpaque(true);
	    surgeons.setForeground(Color.WHITE);
		surgeons.addMouseListener(this);
        surgeons.addActionListener(this);
		panel.add(surgeons);
		
		back9 = new JButton("<<");
		back9.setBounds(20, 20, 80, 40);
        back9.setBackground(Color.decode("#778899"));
		back9.setFont(new Font("Copper BLACK",Font.BOLD,25));
		back9.setFocusable(false);
		back9.setOpaque(true);
	    back9.setForeground(Color.WHITE);
		back9.addMouseListener(this);
        back9.addActionListener(this);
		panel.add(back9);
		
		this.setVisible(true);
		this.add(panel);
	}
		
		
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){
		if(me.getSource()==back9)
		{
			back9.setBackground(Color.RED);
		}
	}
	public void mouseExited(MouseEvent me){
		if(me.getSource()==back9)
		{
			back9.setBackground(Color.decode("#778899"));
		}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String command=ae.getActionCommand();
		
		if(orthopedics.getText().equals(command))
		{
			new orthopedics();
			
			this.setVisible(false);
		}
		
		else if(dermatology.getText().equals(command))
		{
			new dermatology();
			
			this.setVisible(false);
		}
		else if(gynecology.getText().equals(command))
		{
			new gynecology();
			
			this.setVisible(false);
		}
		
		else if(pathology.getText().equals(command))
		{
			new pathology();
			
			this.setVisible(false);
		}
		else if(cardiology.getText().equals(command))
		{
			new cardiology();
			
			this.setVisible(false);
		}
		else if(psychiatry.getText().equals(command))
		{
			new psychiatry();
			
			this.setVisible(false);
		}
		else if(dental.getText().equals(command))
		{
			new dental();
			
			this.setVisible(false);
		}
		else if(eyesp.getText().equals(command))
		{
			new eyesp();
			
			this.setVisible(false);
		}
		else if(physicians.getText().equals(command))
		{
			new physicians();
			this.setVisible(false);
		}
		else if(surgeons.getText().equals(command))
		{
			new surgeons();
			this.setVisible(false);
		}
		else if(back9.getText().equals(command))
		{
			home hh=new home();
			hh.setVisible(true);
			this.setVisible(false);
		}
		
	
	}

}
	