package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class eyesp extends JFrame implements MouseListener,ActionListener
{
	JButton doctorname12,doctorname13,fee12,fee13,appointment12,appointment13,back16;
	JPanel panel;
	Color mycolor;

	public eyesp()
	{
		super("Eye Specialists");
		this.setSize(800,600);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		mycolor=new Color(176,196,222);
		
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor);
		
		doctorname12 = new JButton("DR.MALIHA KHANAM");
		doctorname12.setBounds(100, 200, 200, 30);
		doctorname12.setBackground(Color.decode("#E0FFFF"));
		doctorname12.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname12.setFocusable(false);
		doctorname12.setOpaque(true);
		doctorname12.setForeground(Color.BLACK);
		doctorname12.addMouseListener(this);
		doctorname12.addActionListener(this);
		panel.add(doctorname12);
		
		doctorname13 = new JButton("DR.SAIFUL ISLAM");
		doctorname13.setBounds(450,200, 200, 30);
		doctorname13.setBackground(Color.decode("#E0FFFF"));
		doctorname13.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname13.setFocusable(false);
		doctorname13.setOpaque(true);
		doctorname13.setForeground(Color.BLACK);
		doctorname13.addMouseListener(this);
		doctorname13.addActionListener(this);
		panel.add(doctorname13);
		
		fee12 = new JButton("TIME:9-12 AM");
		fee12.setBounds(100, 230, 200, 30);
		fee12.setBackground(Color.decode("#E0FFFF"));
		fee12.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee12.setFocusable(false);
		fee12.setOpaque(true);
		fee12.setForeground(Color.BLACK);
		fee12.addMouseListener(this);
		fee12.addActionListener(this);
		panel.add(fee12);
		
		fee13 = new JButton("TIME:6-9 PM");
		fee13.setBounds(450, 230, 200, 30);
		fee13.setBackground(Color.decode("#E0FFFF"));
		fee13.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee13.setFocusable(false);
		fee13.setOpaque(true);
		fee13.setForeground(Color.BLACK);
		fee13.addMouseListener(this);
		fee13.addActionListener(this);
		panel.add(fee13);
		
		appointment12 = new JButton("GET APPOINTMENT");
		appointment12.setBounds(100,300, 200, 30);
		appointment12.setBackground(Color.decode("#E0FFFF"));
		appointment12.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment12.setFocusable(false);
		appointment12.setOpaque(true);
		appointment12.setForeground(Color.BLACK);
		appointment12.addMouseListener(this);
		appointment12.addActionListener(this);
		panel.add(appointment12);
		
		appointment13 = new JButton("GET APPOINTMENT");
		appointment13.setBounds(450,300,200, 30);
		appointment13.setBackground(Color.decode("#E0FFFF"));
		appointment13.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment13.setFocusable(false);
		appointment13.setOpaque(true);
		appointment13.setForeground(Color.BLACK);
		appointment13.addMouseListener(this);
		appointment13.addActionListener(this);
		panel.add(appointment13);
		
		back16 = new JButton("<<");
		back16.setBounds(20,10,80,40);
		back16.setBackground(Color.decode("#B0C4DE"));
		back16.setFont(new Font("Copper BLACK",Font.BOLD,25));
		back16.setFocusable(false);
		back16.setOpaque(true);
		back16.setForeground(Color.BLACK);
		back16.addMouseListener(this);
		back16.addActionListener(this);
		panel.add(back16);
		
		this.setVisible(true);
		this.add(panel);
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){
		if(me.getSource()==back16)
		{
			back16.setBackground(Color.RED);
		}
	}
	public void mouseExited(MouseEvent me){
		if(me.getSource()==back16)
		{
			back16.setBackground(Color.decode("#B0C4DE"));
		}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String command = ae.getActionCommand();
		
		{
			if (appointment12.getText().equals(command))
			{
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (appointment13.getText().equals(command))
			    {
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (back16.getText().equals(command))
				{
					docdep dd=new docdep();
				    dd.setVisible(true);
				    this.setVisible(false);
				}
		}
	}
}