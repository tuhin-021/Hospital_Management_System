package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class dental extends JFrame implements MouseListener,ActionListener
{
	private JButton doctorname10,doctorname11,fee10,fee11,appointment10,appointment11,back15;
	JPanel panel;
	Color mycolor;

	public dental()
	{
		super("Dentists");
		this.setSize(800,600);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		mycolor=new Color(176,196,222);
		
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor);
		
		doctorname10 = new JButton("DR.MALIHA KHANAM");
		doctorname10.setBounds(100, 200, 200, 30);
		doctorname10.setBackground(Color.decode("#E0FFFF"));
		doctorname10.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname10.setFocusable(false);
		doctorname10.setOpaque(true);
		doctorname10.setForeground(Color.BLACK);
		doctorname10.addMouseListener(this);
		doctorname10.addActionListener(this);
		panel.add(doctorname10);
		
		doctorname11 = new JButton("DR.SAIFUL ISLAM");
		doctorname11.setBounds(450,200, 200, 30);
		doctorname11.setBackground(Color.decode("#E0FFFF"));
		doctorname11.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname11.setFocusable(false);
		doctorname11.setOpaque(true);
		doctorname11.setForeground(Color.BLACK);
		doctorname11.addMouseListener(this);
		doctorname11.addActionListener(this);
		panel.add(doctorname11);
		
		fee10 = new JButton("TIME:9-12 AM");
		fee10.setBounds(100, 230, 200, 30);
		fee10.setBackground(Color.decode("#E0FFFF"));
		fee10.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee10.setFocusable(false);
		fee10.setOpaque(true);
		fee10.setForeground(Color.BLACK);
		fee10.addMouseListener(this);
		fee10.addActionListener(this);
		panel.add(fee10);
		
		fee11 = new JButton("TIME:6-9 PM");
		fee11.setBounds(450, 230, 200, 30);
		fee11.setBackground(Color.decode("#E0FFFF"));
		fee11.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee11.setFocusable(false);
		fee11.setOpaque(true);
		fee11.setForeground(Color.BLACK);
		fee11.addMouseListener(this);
		fee11.addActionListener(this);
		panel.add(fee11);
		
		appointment10 = new JButton("GET APPOINTMRNT");
		appointment10.setBounds(100,300, 200, 30);
		appointment10.setBackground(Color.decode("#E0FFFF"));
		appointment10.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment10.setFocusable(false);
		appointment10.setOpaque(true);
		appointment10.setForeground(Color.BLACK);
		appointment10.addMouseListener(this);
		appointment10.addActionListener(this);
		panel.add(appointment10);
		
		appointment11 = new JButton("GET APPOINTMRNT");
		appointment11.setBounds(450,300,200, 30);
		appointment11.setBackground(Color.decode("#E0FFFF"));
		appointment11.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment11.setFocusable(false);
		appointment11.setOpaque(true);
		appointment11.setForeground(Color.BLACK);
		appointment11.addMouseListener(this);
		appointment11.addActionListener(this);
		panel.add(appointment11);
		
		back15 = new JButton("<<");
		back15.setBounds(20,10,80,40);
		back15.setBackground(Color.decode("#B0C4DE"));
		back15.setFont(new Font("Copper BLACK",Font.BOLD,25));
		back15.setFocusable(false);
		back15.setOpaque(true);
		back15.setForeground(Color.BLACK);
		back15.addMouseListener(this);
		back15.addActionListener(this);
		panel.add(back15);
		
		this.setVisible(true);
		this.add(panel);
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){
		if(me.getSource()==back15)
		{
			back15.setBackground(Color.RED);
		}
	}
	public void mouseExited(MouseEvent me){
		if(me.getSource()==back15)
		{
			back15.setBackground(Color.decode("#B0C4DE"));
		}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String command = ae.getActionCommand();
		
		{
			if (appointment10.getText().equals(command))
			{
				JOptionPane.showMessageDialog(null,"APPOINTMRNT CONFIRMED");
				}
				else if (appointment11.getText().equals(command))
			    {
				JOptionPane.showMessageDialog(null,"APPOINTMRNT CONFIRMED");
				}
				else if (back15.getText().equals(command))
				{
					docdep dd=new docdep();
				    dd.setVisible(true);
				    this.setVisible(false);
				}
		
			
		}
	}
	
	public static void main (String [] args){
	new dental();
	}

}