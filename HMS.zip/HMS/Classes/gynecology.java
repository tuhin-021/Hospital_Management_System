package Classes;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class gynecology extends JFrame implements MouseListener,ActionListener
{
	JButton doctorname4,doctorname5,fee4,fee5,appointment4,appointment5,back12;
	JPanel panel;
	Color mycolor;

	public gynecology()
	{
		super("Gynecologists");
		this.setSize(800,600);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		mycolor=new Color(176,196,222);
		
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor);
		
		doctorname4 = new JButton("DR.MALIHA KHANAM");
		doctorname4.setBounds(100, 200, 200, 30);
		doctorname4.setBackground(Color.decode("#E0FFFF"));
		doctorname4.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname4.setFocusable(false);
		doctorname4.setOpaque(true);
		doctorname4.setForeground(Color.BLACK);
		doctorname4.addMouseListener(this);
		doctorname4.addActionListener(this);
		panel.add(doctorname4);
		
		doctorname5 = new JButton("DR.SAIFUL ISLAM");
		doctorname5.setBounds(450,200, 200, 30);
		doctorname5.setBackground(Color.decode("#E0FFFF"));
		doctorname5.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname5.setFocusable(false);
		doctorname5.setOpaque(true);
		doctorname5.setForeground(Color.BLACK);
		doctorname5.addMouseListener(this);
		doctorname5.addActionListener(this);
		panel.add(doctorname5);
		
		fee4 = new JButton("TIME:9-12 AM");
		fee4.setBounds(100, 230, 200, 30);
		fee4.setBackground(Color.decode("#E0FFFF"));
		fee4.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee4.setFocusable(false);
		fee4.setOpaque(true);
		fee4.setForeground(Color.BLACK);
		fee4.addMouseListener(this);
		fee4.addActionListener(this);
		panel.add(fee4);
		
		fee5 = new JButton("TIME:6-9 PM");
		fee5.setBounds(450, 230, 200, 30);
		fee5.setBackground(Color.decode("#E0FFFF"));
		fee5.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee5.setFocusable(false);
		fee5.setOpaque(true);
		fee5.setForeground(Color.BLACK);
		fee5.addMouseListener(this);
		fee5.addActionListener(this);
		panel.add(fee5);
		
		appointment4 = new JButton("GET APPOINTMENT");
		appointment4.setBounds(100,300, 200, 30);
		appointment4.setBackground(Color.decode("#E0FFFF"));
		appointment4.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment4.setFocusable(false);
		appointment4.setOpaque(true);
		appointment4.setForeground(Color.BLACK);
		appointment4.addMouseListener(this);
		appointment4.addActionListener(this);
		panel.add(appointment4);
		
		appointment5 = new JButton("GET APPOINTMENT");
		appointment5.setBounds(450,300,200, 30);
		appointment5.setBackground(Color.decode("#E0FFFF"));
		appointment5.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment5.setFocusable(false);
		appointment5.setOpaque(true);
		appointment5.setForeground(Color.BLACK);
		appointment5.addMouseListener(this);
		appointment5.addActionListener(this);
		panel.add(appointment5);
		
		back12= new JButton("<<");
		back12.setBounds(20,10,80,40);
		back12.setBackground(Color.decode("#B0C4DE"));
		back12.setFont(new Font("Copper BLACK",Font.BOLD,25));
		back12.setFocusable(false);
		back12.setOpaque(true);
		back12.setForeground(Color.BLACK);
		back12.addMouseListener(this);
		back12.addActionListener(this);
		panel.add(back12);
		
		this.setVisible(true);
		this.add(panel);
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){
		if(me.getSource()==back12)
		{
			back12.setBackground(Color.RED);
		}
	}
	public void mouseExited(MouseEvent me){
		if(me.getSource()==back12)
		{
			back12.setBackground(Color.decode("#B0C4DE"));
		}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String command = ae.getActionCommand();
		
		{
			if (appointment4.getText().equals(command))
			{
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (appointment5.getText().equals(command))
			    {
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (back12.getText().equals(command))
				{
					docdep dd=new docdep();
				    dd.setVisible(true);
				    this.setVisible(false);
				}
		
			
		}
	}
}