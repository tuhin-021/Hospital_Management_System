package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class orthopedics extends JFrame implements MouseListener,ActionListener
{
	JButton doctorname,doctorname1,fee,fee1,appointment,appointment1,back10;
	JPanel panel;
	Color mycolor;

	public orthopedics()
	{
		super("Orthopedic Specialists");
		this.setSize(800,600);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		mycolor=new Color(176,196,222);
		
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor);
		
		doctorname = new JButton("DR.MALIHA KHANAM");
		doctorname.setBounds(100, 200, 200, 30);
		doctorname.setBackground(Color.decode("#E0FFFF"));
		doctorname.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname.setFocusable(false);
		doctorname.setOpaque(true);
		doctorname.setForeground(Color.BLACK);
		doctorname.addMouseListener(this);
		doctorname.addActionListener(this);
		panel.add(doctorname);
		
		doctorname1 = new JButton("DR.SAIFUL ISLAM");
		doctorname1.setBounds(450,200, 200, 30);
		doctorname1.setBackground(Color.decode("#E0FFFF"));
		doctorname1.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname1.setFocusable(false);
		doctorname1.setOpaque(true);
		doctorname1.setForeground(Color.BLACK);
		doctorname1.addMouseListener(this);
		doctorname1.addActionListener(this);
		panel.add(doctorname1);
		
		fee = new JButton("TIME:6-9 PM");
		fee.setBounds(100, 230, 200, 30);
		fee.setBackground(Color.decode("#E0FFFF"));
		fee.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee.setFocusable(false);
		fee.setOpaque(true);
		fee.setForeground(Color.BLACK);
		fee.addMouseListener(this);
		fee.addActionListener(this);
		panel.add(fee);
		
		fee1 = new JButton("TIME:9-12 AM");
		fee1.setBounds(450, 230, 200, 30);
		fee1.setBackground(Color.decode("#E0FFFF"));
		fee1.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee1.setFocusable(false);
		fee1.setOpaque(true);
		fee1.setForeground(Color.BLACK);
		fee1.addMouseListener(this);
		fee1.addActionListener(this);
		panel.add(fee1);
		
		appointment = new JButton("GET APPOINTMENT");
		appointment.setBounds(100,300, 200, 30);
		appointment.setBackground(Color.decode("#E0FFFF"));
		appointment.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment.setFocusable(false);
		appointment.setOpaque(true);
		appointment.setForeground(Color.BLACK);
		appointment.addMouseListener(this);
		appointment.addActionListener(this);
		panel.add(appointment);
		
		appointment1 = new JButton("GET APPOINTMENT");
		appointment1.setBounds(450,300,200, 30);
		appointment1.setBackground(Color.decode("#E0FFFF"));
		appointment1.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment1.setFocusable(false);
		appointment1.setOpaque(true);
		appointment1.setForeground(Color.BLACK);
		appointment1.addMouseListener(this);
		appointment1.addActionListener(this);
		panel.add(appointment1);
		
		back10 = new JButton("<<");
		back10.setBounds(20,10,80,40);
		back10.setBackground(Color.decode("#B0C4DE"));
		back10.setFont(new Font("Copper BLACK",Font.BOLD,25));
		back10.setFocusable(false);
		back10.setOpaque(true);
		back10.setForeground(Color.BLACK);
		back10.addMouseListener(this);
		back10.addActionListener(this);
		panel.add(back10);
		
		this.setVisible(true);
		this.add(panel);
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){
		if(me.getSource()==back10)
		{
			back10.setBackground(Color.RED);
		}
	}
	public void mouseExited(MouseEvent me){
		if(me.getSource()==back10)
		{
			back10.setBackground(Color.decode("#B0C4DE"));
		}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String command = ae.getActionCommand();
		
		{
			if (appointment.getText().equals(command))
			{
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (appointment1.getText().equals(command))
			    {
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (back10.getText().equals(command))
				{
					docdep dd=new docdep();
				    dd.setVisible(true);
				    this.setVisible(false);
				}
		
			
		}
	}

}