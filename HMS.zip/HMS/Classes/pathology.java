package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class pathology extends JFrame implements MouseListener,ActionListener
{
	JButton doctorname6,doctorname7,fee6,fee7,appointment6,appointment7,back13;
	JPanel panel;
	Color mycolor;

	public pathology()
	{
		super("Pathologists");
        this.setSize(800,600);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		mycolor=new Color(176,196,222);
		
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor);
		
		doctorname6 = new JButton("DR.MALIHA KHANAM");
		doctorname6.setBounds(100, 200, 200, 30);
		doctorname6.setBackground(Color.decode("#E0FFFF"));
		doctorname6.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname6.setFocusable(false);
		doctorname6.setOpaque(true);
		doctorname6.setForeground(Color.BLACK);
		doctorname6.addMouseListener(this);
		doctorname6.addActionListener(this);
		panel.add(doctorname6);
		
		doctorname7 = new JButton("DR.SAIFUL ISLAM");
		doctorname7.setBounds(450,200, 200, 30);
		doctorname7.setBackground(Color.decode("#E0FFFF"));
		doctorname7.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname7.setFocusable(false);
		doctorname7.setOpaque(true);
		doctorname7.setForeground(Color.BLACK);
		doctorname7.addMouseListener(this);
		doctorname7.addActionListener(this);
		panel.add(doctorname7);
		
		fee6 = new JButton("TIME:9-12 AM");
		fee6.setBounds(100, 230, 200, 30);
		fee6.setBackground(Color.decode("#E0FFFF"));
		fee6.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee6.setFocusable(false);
		fee6.setOpaque(true);
		fee6.setForeground(Color.BLACK);
		fee6.addMouseListener(this);
		fee6.addActionListener(this);
		panel.add(fee6);
		
		fee7 = new JButton("TIME:6-9 PM");
		fee7.setBounds(450, 230, 200, 30);
		fee7.setBackground(Color.decode("#E0FFFF"));
		fee7.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee7.setFocusable(false);
		fee7.setOpaque(true);
		fee7.setForeground(Color.BLACK);
		fee7.addMouseListener(this);
		fee7.addActionListener(this);
		panel.add(fee7);
		
		appointment6 = new JButton("GET APPOINTMENT");
		appointment6.setBounds(100,300, 200, 30);
		appointment6.setBackground(Color.decode("#E0FFFF"));
		appointment6.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment6.setFocusable(false);
		appointment6.setOpaque(true);
		appointment6.setForeground(Color.BLACK);
		appointment6.addMouseListener(this);
		appointment6.addActionListener(this);
		panel.add(appointment6);
		
		appointment7 = new JButton("GET APPOINTMENT");
		appointment7.setBounds(450,300,200, 30);
		appointment7.setBackground(Color.decode("#E0FFFF"));
		appointment7.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment7.setFocusable(false);
		appointment7.setOpaque(true);
		appointment7.setForeground(Color.BLACK);
		appointment7.addMouseListener(this);
		appointment7.addActionListener(this);
		panel.add(appointment7);
		
		back13 = new JButton("<<");
		back13.setBounds(20,10,80,40);
		back13.setBackground(Color.decode("#B0C4DE"));
		back13.setFont(new Font("Copper BLACK",Font.BOLD,25));
		back13.setFocusable(false);
		back13.setOpaque(true);
		back13.setForeground(Color.BLACK);
		back13.addMouseListener(this);
		back13.addActionListener(this);
		panel.add(back13);
		
		this.setVisible(true);
		this.add(panel);
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){
		if(me.getSource()==back13)
		{
			back13.setBackground(Color.RED);
		}
	}
	public void mouseExited(MouseEvent me){
		if(me.getSource()==back13)
		{
			back13.setBackground(Color.decode("#B0C4DE"));
		}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String command = ae.getActionCommand();
		
		{
			if (appointment6.getText().equals(command))
			{
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (appointment7.getText().equals(command))
			    {
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (back13.getText().equals(command))
				{
					docdep dd=new docdep();
				    dd.setVisible(true);
				    this.setVisible(false);
				}
		
			
		}
	}

}