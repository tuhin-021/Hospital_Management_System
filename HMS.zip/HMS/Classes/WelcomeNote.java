package Classes;
import javax.swing.*;
import javax.swing.border.Border;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class WelcomeNote extends JFrame{
    public JFrame jFrame;
    public JLabel pic,jLabel1,l2;
    public JPanel jPanel;
    
    public JButton jButton;

    public WelcomeNote(){
        jFrame= new JFrame("Welcome to HMS");
        jFrame.setSize(800,640);

        jPanel =new JPanel();
        jPanel.setBounds(0,0,800,600);

        jPanel.setBackground(Color.decode("#ABFF6D"));
        jPanel.setLayout(null);

        l2 =new JLabel("    Hospital Management System");
        l2.setBounds(150,6,500,60);
        Border border = BorderFactory.createLineBorder(Color.BLUE, 4); // Blue border, 4 pixels wide            
        //adding the border in jLebel1
        l2.setBorder(border);


        l2.setFont(new Font("Serif", Font.PLAIN, 34));
        jPanel.add(l2);

        
        ImageIcon icon = new ImageIcon("Images/Welcome.jpg");
        pic=new JLabel(icon);
        pic.setBounds(100,65,600,550);
        pic.setBackground(Color.decode("#42f5ad"));
        jPanel.add(pic);

        jButton=new JButton("START");
        jButton.setBounds(330,500,150,50);
        jButton.setBackground(Color.decode("#D90229"));
        jButton.setForeground(Color.WHITE);
        jButton.setFont(new Font("abadi", Font.PLAIN, 24));



        jButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
              jFrame.setVisible(false);
              new Login("textField1","textField2");
              System.out.println("START Button clicked");
            }
          });

          jPanel.add(jButton);
          jFrame.add(jPanel);
                  //jFrame.add(jButton);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setLocationRelativeTo(null);
        jFrame.setLayout(null);
        jFrame.setVisible(true);
        jFrame.setResizable(false);        
    }
}