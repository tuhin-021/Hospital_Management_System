package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class physicians extends JFrame implements MouseListener,ActionListener
{
	JButton doctorname14,doctorname15,fee14,fee15,appointment14,appointment15,back17;
	JPanel panel;
	Color mycolor;

	public physicians()
	{
		super("physicians");
		this.setSize(800,600);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		mycolor=new Color(176,196,222);
		
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor);
		
		doctorname14 = new JButton("DR.MALIHA KHANAM");
		doctorname14.setBounds(100, 200, 200, 30);
		doctorname14.setBackground(Color.decode("#E0FFFF"));
		doctorname14.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname14.setFocusable(false);
		doctorname14.setOpaque(true);
		doctorname14.setForeground(Color.BLACK);
		doctorname14.addMouseListener(this);
		doctorname14.addActionListener(this);
		panel.add(doctorname14);
		
		doctorname15 = new JButton("DR.SAIFUL ISLAM");
		doctorname15.setBounds(450,200, 200, 30);
		doctorname15.setBackground(Color.decode("#E0FFFF"));
		doctorname15.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname15.setFocusable(false);
		doctorname15.setOpaque(true);
		doctorname15.setForeground(Color.BLACK);
		doctorname15.addMouseListener(this);
		doctorname15.addActionListener(this);
		panel.add(doctorname15);
		
		fee14 = new JButton("TIME:6-9 PM");
		fee14.setBounds(100, 230, 200, 30);
		fee14.setBackground(Color.decode("#E0FFFF"));
		fee14.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee14.setFocusable(false);
		fee14.setOpaque(true);
		fee14.setForeground(Color.BLACK);
		fee14.addMouseListener(this);
		fee14.addActionListener(this);
		panel.add(fee14);
		
		fee15 = new JButton("TIME:9-12 AM");
		fee15.setBounds(450, 230, 200, 30);
		fee15.setBackground(Color.decode("#E0FFFF"));
		fee15.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee15.setFocusable(false);
		fee15.setOpaque(true);
		fee15.setForeground(Color.BLACK);
		fee15.addMouseListener(this);
		fee15.addActionListener(this);
		panel.add(fee15);
		
		appointment14 = new JButton("GET APPOINTMENT");
		appointment14.setBounds(100,300, 200, 30);
		appointment14.setBackground(Color.decode("#E0FFFF"));
		appointment14.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment14.setFocusable(false);
		appointment14.setOpaque(true);
		appointment14.setForeground(Color.BLACK);
		appointment14.addMouseListener(this);
		appointment14.addActionListener(this);
		panel.add(appointment14);
		
		appointment15 = new JButton("GET APPOINTMENT");
		appointment15.setBounds(450,300,200, 30);
		appointment15.setBackground(Color.decode("#E0FFFF"));
		appointment15.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment15.setFocusable(false);
		appointment15.setOpaque(true);
		appointment15.setForeground(Color.BLACK);
		appointment15.addMouseListener(this);
		appointment15.addActionListener(this);
		panel.add(appointment15);
		
		back17 = new JButton("<<");
		back17.setBounds(20,10,80,40);
		back17.setBackground(Color.decode("#B0C4DE"));
		back17.setFont(new Font("Copper BLACK",Font.BOLD,25));
		back17.setFocusable(false);
		back17.setOpaque(true);
		back17.setForeground(Color.BLACK);
		back17.addMouseListener(this);
		back17.addActionListener(this);
		panel.add(back17);
		
		this.setVisible(true);
		this.add(panel);
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){
		if(me.getSource()==back17)
		{
			back17.setBackground(Color.RED);
		}
	}
	public void mouseExited(MouseEvent me){
		if(me.getSource()==back17)
		{
			back17.setBackground(Color.decode("#B0C4DE"));
		}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String command = ae.getActionCommand();
		
		{
			if (appointment14.getText().equals(command))
			{
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (appointment15.getText().equals(command))
			    {
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (back17.getText().equals(command))
				{
					docdep dd=new docdep();
				    dd.setVisible(true);
				    this.setVisible(false);
				}
		
			
		}
	}

}