package Classes;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class dermatology extends JFrame implements MouseListener,ActionListener
{
	JButton doctorname2,doctorname3,fee2,fee3,appointment2,appointment3,back11;
	JPanel panel;
	Color mycolor;

	public dermatology()
	{
		super("Dermatologists");
		this.setSize(800,600);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null);
		mycolor=new Color(176,196,222);
		
		
		panel = new JPanel();
		panel.setLayout(null);
		panel.setBackground(mycolor);
		
		doctorname2 = new JButton("DR.SAIFUL ISLAM");
		doctorname2.setBounds(100, 200, 200, 30);
		doctorname2.setBackground(Color.decode("#E0FFFF"));
		doctorname2.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname2.setFocusable(false);
		doctorname2.setOpaque(true);
		doctorname2.setForeground(Color.BLACK);
		doctorname2.addMouseListener(this);
		doctorname2.addActionListener(this);
		panel.add(doctorname2);
		
		doctorname3 = new JButton("DR.MALIHA KHANAM");
		doctorname3.setBounds(450,200, 200, 30);
		doctorname3.setBackground(Color.decode("#E0FFFF"));
		doctorname3.setFont(new Font("Copper BLACK",Font.BOLD,15));
		doctorname3.setFocusable(false);
		doctorname3.setOpaque(true);
		doctorname3.setForeground(Color.BLACK);
		doctorname3.addMouseListener(this);
		doctorname3.addActionListener(this);
		panel.add(doctorname3);
		
		fee2 = new JButton("TIME:9-12 AM");
		fee2.setBounds(100, 230, 200, 30);
		fee2.setBackground(Color.decode("#E0FFFF"));
		fee2.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee2.setFocusable(false);
		fee2.setOpaque(true);
		fee2.setForeground(Color.BLACK);
		fee2.addMouseListener(this);
		fee2.addActionListener(this);
		panel.add(fee2);
		
		fee3 = new JButton("TIME:6-9 PM");
		fee3.setBounds(450, 230, 200, 30);
		fee3.setBackground(Color.decode("#E0FFFF"));
		fee3.setFont(new Font("Copper BLACK",Font.BOLD,15));
		fee3.setFocusable(false);
		fee3.setOpaque(true);
		fee3.setForeground(Color.BLACK);
		fee3.addMouseListener(this);
		fee3.addActionListener(this);
		panel.add(fee3);
		
		appointment2 = new JButton("GET APPOINTMENT");
		appointment2.setBounds(100,300, 200, 30);
		appointment2.setBackground(Color.decode("#E0FFFF"));
		appointment2.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment2.setFocusable(false);
		appointment2.setOpaque(true);
		appointment2.setForeground(Color.BLACK);
		appointment2.addMouseListener(this);
		appointment2.addActionListener(this);
		panel.add(appointment2);
		
		appointment3 = new JButton("GET APPOINTMENT");
		appointment3.setBounds(450,300,200, 30);
		appointment3.setBackground(Color.decode("#E0FFFF"));
		appointment3.setFont(new Font("Copper BLACK",Font.BOLD,15));
		appointment3.setFocusable(false);
		appointment3.setOpaque(true);
		appointment3.setForeground(Color.BLACK);
		appointment3.addMouseListener(this);
		appointment3.addActionListener(this);
		panel.add(appointment3);
		
		back11 = new JButton("<<");
		back11.setBounds(20,10,80,40);
		back11.setBackground(Color.decode("#B0C4DE"));
		back11.setFont(new Font("Copper BLACK",Font.BOLD,25));
		back11.setFocusable(false);
		back11.setOpaque(true);
		back11.setForeground(Color.BLACK);
		back11.addMouseListener(this);
		back11.addActionListener(this);
		panel.add(back11);
		
		this.setVisible(true);
		this.add(panel);
	}
	
	public void mouseClicked(MouseEvent me){}
	public void mousePressed(MouseEvent me){}
	public void mouseReleased(MouseEvent me){}
	public void mouseEntered(MouseEvent me){
		if(me.getSource()==back11)
		{
			back11.setBackground(Color.RED);
		}
	}
	public void mouseExited(MouseEvent me){
		if(me.getSource()==back11)
		{
			back11.setBackground(Color.decode("#B0C4DE"));
		}
	}
	
	
	public void actionPerformed(ActionEvent ae)
	{
		String command = ae.getActionCommand();
		
		{
			if (appointment2.getText().equals(command))
			{
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (appointment3.getText().equals(command))
			    {
				JOptionPane.showMessageDialog(null,"APPOINTMENT CONFIRMED");
				}
				else if (back11.getText().equals(command))
				{
					docdep dd=new docdep();
				    dd.setVisible(true);
				    this.setVisible(false);
				}
		
			
		}
	}
}